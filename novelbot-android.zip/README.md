# Novel Bot Android app

A real installable app: the Novel Bot page in a fullscreen WebView. Nothing to
install on your side — GitHub builds the APK in the cloud.

## Build it in the cloud (phone-friendly)

1. Create a new empty repo (e.g. NovelBot-App). Do NOT reuse your website repo.
2. Upload **the contents of this folder** to the repo root, so
   `settings.gradle` sits at `/`.
3. Rename `gitignore.txt` to `.gitignore`:
   open the file, tap the pencil, rename to `.gitignore`.
4. Move the workflow into place: open `github-workflows/build-apk.yml`,
   tap the pencil, rename it to `.github/workflows/build-apk.yml`
   (GitHub only runs workflows from there).
5. Actions tab → **Build NovelBot APK** → runs by itself. Wait ~5–10 min.
6. Download the `novelbot-apk` artifact, unzip in Files, tap the APK to
   install (allow "install unknown apps" once).

All builds share one signing key (`novelbot-debug.p12`, committed — do not
delete it), so every new APK installs over the old one as an update: your
library and settings carry over.

## Updating the app

Never delete the repo. To ship a new version: overwrite
`app/src/main/assets/www/index.html` with the new file, commit, wait for the
build, install the new APK over the old one.

## In the app

Open it, fill **AI Settings** (any OpenAI-compatible base URL + key + model),
then make novels exactly like the website. Library and settings stay on the
phone.
